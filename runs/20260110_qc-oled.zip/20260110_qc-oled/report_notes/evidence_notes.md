- 범위: 제공된 런/아카이브/서포팅 폴더에서 **OLED 발광재료 개발 관점의 양자컴퓨팅 적용** 관련 “증거(원문 인용 가능한 문장)”만 추출.  
- 주의: 일부 핵심은 **최근 12개월(2025-01~2026-01)** 밖(2021)이나, “OLED×QC” 직접 근거라서 포함.

---

## 1) 공식 보도자료/기업 발표 (Primary에 준하는 1차 문서)

### Mitsubishi Chemical Corporation (PDF 보도자료)
- 핵심 주장: OLED 재료(특히 TADF) **여기상태(excited states) 예측을 양자컴퓨터로 수행**한 공동 연구가 npj Computational Materials에 게재되었다고 발표.
  - 근거: “A Joint Paper on Prediction of Optical Properties of OLED Materials… has been published in ‘npj Computational Materials’…”[supporting/20260111_215826/web_text/001_mcgc.com_english_news_mcc_2021___icsFiles_afieldfile_2021_05_26_qhubeng.pdf-2cdf61db.txt] (원문 URL: https://www.mcgc.com/english/news_mcc/2021/__icsFiles/afieldfile/2021/05/26/qhubeng.pdf)
- 워크플로/알고리즘(정량 조건 포함)
  - 주장: 고전 계산은 큰 분자의 ab initio 여기상태 계산이 시간적으로 demanding이며, 여기상태에 대한 **양자 알고리즘의 (잠재적) exponential speedup**이 제안되어 왔다.
    - 근거: “ab initio calculation of excited states of large size molecules… rather demanding… quantum algorithms for exponential speedup of excited state calculations…”[supporting/.../qhubeng...txt]
  - 주장: 본 연구는 **qEOM‑VQE, VQD**로 TADF 발광체의 S1/T1 여기상태 에너지(ΔEST)를 예측하는 것을 목표로 했다.
    - 근거: “The goal of the work is to use two quantum algorithms (qEOM-VQE and VQD algorithms) to reliably predict excited states energies of TADF materials…”[supporting/.../qhubeng...txt]
  - 주장: 대상 분자/액티브 스페이스/실행 환경
    - 근거: “three TADF molecules (PSPCz, 2F-PSPCz, and 4F-PSPCZ)… HOMO and LUMO… used as an active space… on noise-free quantum computer simulator and IBM quantum computers.”[supporting/.../qhubeng...txt]
  - 주장: 시뮬레이터 결과는 실험과 높은 상관(ΔEST)이나, 실제 IBM 양자컴퓨터는 노이즈로 정확도 저하 → 에러 완화 필요.
    - 근거: “Excellent agreement (correlation coefficient of 0.99)… Fig 1 also indicates that the calculations on IBM quantum computers can not accurately calculate…”[supporting/.../qhubeng...txt]
  - 주장: **양자 토모그래피 기반 error mitigation**을 제안했고, 오차를 88 mHa → 약 4 mHa 수준으로 개선했다고 주장.
    - 근거: “a new error mitigation scheme using quantum tomography techniques… a maximum difference of 88 mHa… improved to approximately 4 mHa.”[supporting/.../qhubeng...txt]

---

## 2) 기업 웹페이지/보도자료/블로그 (Supporting: 주장 신뢰는 ‘자사 주장’으로 제한)

### JSR Corporation 뉴스 (2021-05-26)
- 주장: “OLED 재료의 여기상태를 양자컴퓨터로 계산한 세계 최초(world first)” 성격의 연구를 발표했다고 서술.
  - 근거: “The World First Calculation of the Excited States of OLED Materials on Quantum Computers”[supporting/20260111_215826/web_extract/002_jsr.co.jp_jsr_e_news_2021_20210526.html-0caa1018.txt] (원문 URL: https://www.jsr.co.jp/jsr_e/news/2021/20210526.html)
- 주장: IBM Quantum Network Hub at Keio University(2018 개소) 및 Mitsubishi Chemical/JSR 참여를 명시.
  - 근거: “Opened in May 2018… brings together academia and industry, with Mitsubishi Chemical and JSR as founding members.”[supporting/.../002_jsr...txt]

### IBM Quantum Blog (2021-07-27)
- 주장: 일본 가와사키에 설치된 IBM Quantum System One과, 일본 내 산학 협력(Keio hub, Tokyo partnership)을 설명.
  - 근거: “researchers in Japan received an IBM Quantum System One, now installed…”[supporting/20260111_215826/web_extract/003_ibm.com_quantum_blog_japan-quantum-system-one-ee404943.txt] (원문 URL: https://www.ibm.com/quantum/blog/japan-quantum-system-one)
- OLED 관련 연결: Mitsubishi Chemical/Keio/JSR/IBM이 “산업용 화합물”의 복잡한 거동 이해를 위한 알고리즘 개발 중이며, 응용 분야에 **OLED device**를 포함한다고 언급.
  - 근거: “developing new quantum algorithms to understand the complex behavior of industrial chemical compounds… applications for… organic light-emitting diode (OLED) devices.”[supporting/.../003_ibm...txt]

### OTI Lumionics (기업 웹: “Quantum Computing” 페이지)
- 주장(회사 포지셔닝): 양자/양자영감 소프트웨어로 재료과학·화학 문제 해결, “excited states mapping” 등을 열거.
  - 근거: “building powerful quantum and quantum-inspired software… *Excited states mapping* …”[supporting/20260111_215826/web_extract/004_otilumionics.com_quantum-computing-b2e940d9.txt] (원문 URL: https://otilumionics.com/quantum-computing/)
- 연구 링크(자사 큐레이션): Qubit coupled-cluster(QCC), constrained VQE 등 관련 논문/프리프린트 링크를 “Recent Publications”로 나열.
  - 근거: “Qubit coupled-cluster (QCC) method… Constrained Variational Quantum Eigensolver…”[supporting/.../004_otilumionics...txt]

### GlobeNewswire 보도자료 (OTI Lumionics, 2025-06-18)
- 주장: “클래식 컴퓨터에서 Qubit Coupled Cluster Ansatz 최적화”로 “오늘날 큰 규모 양자 시뮬레이션을 클래식에서 고정확으로 시뮬레이션 가능” 및 OLED 응용을 직접 언급.
  - 근거: “bypass the limitations of today’s quantum hardware… accelerating materials design pipelines, especially for OLED applications…”[archive/tavily_search.jsonl에 포함된 원문 요약 인용] (원문 URL: https://www.globenewswire.com/news-release/2025/06/18/3101674/0/en/OTI-Lumionics-Releases-Breakthrough-Algorithms-for-Quantum-Chemistry-Simulations.html)
  - 주의: 본 런 폴더에는 **해당 URL의 본문 추출 파일이 없고 tavily 요약만 존재**(직접 인용은 원문 fetch 필요).

---

## 3) 학술 논문(저널 페이지/출판사 PDF) (Primary)

### npj Computational Materials (Nature) — OLED×QC 직접 논문 페이지
- 연구 주제: TADF 발광체(OLED용)에서 QC 알고리즘(VQE 계열)로 바닥/여기상태 에너지 계산 및 ΔEST 예측.
  - 근거: “VQE, qEOM-VQE, and VQD… ground and excited state energies of industrially relevant molecules… TADF emitters suitable for OLED applications”[archive/tavily_search.jsonl 요약 인용] (원문 URL: https://www.nature.com/articles/s41524-021-00540-6)
- 결론(요약에 포함된 범위): 시뮬레이터에서 qEOM‑VQE/VQD가 exact diagonalization을 재현하고 ΔEST가 실험과 부합, “구조 변화와 여기상태 에너지 관계 이해/설계 지원” 가능성을 언급.
  - 근거: “accurately reproduced… reliable prediction of ΔEST… could aid in the design of TADF emitters.”[archive/tavily_search.jsonl 요약 인용] (원문 URL 동일)
- 주의: 이 런 폴더에는 **Nature 페이지 전문 추출 파일이 없음** → 보고서에 문장 단위 직접 인용을 하려면 원문 저장 필요.

### Nature Communications (2025) — GNN 기반 분자 생성(비QC, 비교용)
- 워크플로 주장: 사전학습된 GNN property predictor를 고정한 채, 입력(분자 그래프)을 gradient ascent로 최적화하여 목표 물성(예: band gap)을 만족하는 분자를 생성.
  - 근거: “perform a gradient ascent while holding the GNN weights fixed… optimize its input, the molecular graph, towards the target property.”[archive/openalex/text/W4410193211.txt] (원문 PDF URL: https://www.nature.com/articles/s41467-025-59439-1.pdf)
- 검증: 생성 분자의 에너지 갭을 DFT로 검증했다고 서술.
  - 근거: “generating molecules with specific energy gaps verified with density functional theory (DFT)”[archive/openalex/text/W4410193211.txt]

### Journal of Materials Science: Materials in Engineering (2025) — quantum materials 리뷰(오프토픽 가능)
- 범위: “quantum materials(QMs)”의 성질·응용을 폭넓게 리뷰(양자컴퓨팅으로 OLED 재료 설계라는 본 과제와는 직접성 낮음).
  - 근거: “Exploring quantum materials and applications: a review… overview… properties… applications”[archive/openalex/text/W4406477905.txt] (원문 PDF URL: https://jmsg.springeropen.com/counter/pdf/10.1186/s40712-024-00202-7)

### Journal of Pioneering Artificial Intelligence Research (2025) — Quantum-AI synergy 리뷰(출처 신뢰도 주의)
- 주장: 양자-AI 통합 전반을 다루며, “평가 프레임워크”를 제안한다고 주장.
  - 근거: “Comprehensive Evaluation Framework for Quantum Advantage Assessment…”[archive/openalex/text/W4417018335.txt] (원문 DOI URL: https://doi.org/10.63721/25jpair0118)
- 주의: OLED/양자화학 직접 근거가 아니며, 저널/주장(산업 성과 수치 등) 검증 필요.

---

## 4) 수집/커버리지 한계에 대한 ‘메타 근거’ (로그)

- OpenAlex에서 일부 Wiley/ASME PDF가 **403 Forbidden**으로 다운로드 실패 → 12개월 내 최신 OLED/QC 관련 논문 커버리지가 제한될 수 있음.
  - 근거: “ERROR openalex pdf download failed… HTTPError('403 Client Error: Forbidden … wiley.com …')”[archive/_log.txt]
- Tavily 쿼리에 Samsung Display/LG Display/UDC 관련 검색이 포함되었음을 확인(결과의 빈약/부재는 별도 근거 필요).
  - 근거: “TAVILY SEARCH: Samsung Display…”, “LG Display…”, “Universal Display Corporation…”[archive/_log.txt]

---

원하시는 “근거 테이블(Claim ID–주장–근거–한계–해석–근거강도)” 형태로 위 소스들을 재구성해 드릴 수도 있습니다.