## 1) 아카이브 맵(coverage 확인: 인덱스/JSONL 우선)

### A. 인덱스/메타데이터(필독)
- `archive/20260110_qc-oled-index.md`  
  - 수집 범위 요약: **Tavily 9 queries(URL 0으로 표기되나 jsonl에는 다수 결과 포함), OpenAlex works 5 OA max로 7개 PDF 다운로드**  
  - OLED/양자컴퓨팅 직접 타깃 소스가 OpenAlex 쪽에서는 거의 안 잡혔고, **Tavily에서 IBM/Keio/Mitsubishi/JSR 및 OTI Lumionics** 관련이 잡힘.
- `archive/tavily_search.jsonl` *(소스 커버리지 핵심)*  
  - OLED×양자컴퓨팅 직접 관련 결과 포함(IBM Research 블로그, npj Computational Materials 논문 페이지, Mitsubishi Chemical PDF, OTI Lumionics 보도자료 등).
- `archive/openalex/works.jsonl` *(학술 PDF 인덱스)*  
  - 다운로드된 7개 PDF 중 **OLED/양자컴퓨팅 직접 연관은 낮고**, 다수가 “quantum materials review”, “Quantum-AI synergy(일반론)”, “GNN molecule generator(일반 ML)” 등으로 **초점 이탈 가능성** 큼.

### B. OpenAlex 풀텍스트/PDF(7종)
- `archive/openalex/pdf/W4406477905.pdf` + `archive/openalex/text/W4406477905.txt`  
  - *Exploring quantum materials and applications: a review* (2025) : “quantum materials” 리뷰(양자컴퓨팅 기반 재료설계보다는 물질계 자체가 주제일 가능성)
- `archive/openalex/pdf/W4410193211.pdf` + `archive/openalex/text/W4410193211.txt`  
  - *Using GNN property predictors as molecule generators* (Nature Communications 2025): 분자 생성/예측(양자컴퓨팅 아님). 다만 워크플로 비교(클래식 ML vs QC) 용도로 보조 가능
- `archive/openalex/pdf/W4417018335.pdf` + `archive/openalex/text/W4417018335.txt`  
  - *Quantum-AI Synergy and the Framework for Assessing Quantum Advantage* (2025): 일반 프레임워크(주장 강도 낮을 수 있음)
- `archive/openalex/pdf/W4410446803.pdf` + `archive/openalex/text/W4410446803.txt`  
  - *Forecasting the future: From quantum chips…* (2025): 전망성 글(출처 신뢰도/근거 강도 검증 필요)
- `archive/openalex/pdf/W4406330631.pdf` + `archive/openalex/text/W4406330631.txt`  
  - organoluminophores/나노닷 리뷰(양자컴퓨팅 직접성 낮음)
- `archive/openalex/pdf/W4406399672.pdf`, `archive/openalex/pdf/W4406707630.pdf` 및 대응 txt  
  - 건축 파사드/간암 나노+AI 리뷰 등 **오프토픽** 가능성 높음

### C. 런/운영 로그
- `archive/_job.json`, `archive/_log.txt`  
  - 수집 설정/실패/누락 원인 확인용(예: OLED+quantum 관련 학술 논문이 OpenAlex에 제대로 안 잡힌 이유 등)

---

## 2) 핵심 소스 파일 인벤토리(보고서 초점 기준)

### 2.1 “Primary(논문/공식발표/리뷰)” 후보
- (Tavily 내 링크) **npj Computational Materials 논문 페이지**: *Applications of quantum computing for investigations of electronic transitions in Phenylsulfonyl-carbazole TADF Emitters* (2021)  
  - 12개월 범위 밖이지만, **OLED×양자컴퓨팅에서 “가장 직접적이고 재현 가능한 공개 근거”**라서 배경/방법론(algorithms: VQE, qEOM-VQE, VQD, error mitigation) 파트에 사실상 필수.
- (Tavily 내 PDF) Mitsubishi Chemical 관련 PDF(2021): `https://www.mcgc.com/.../qhubeng.pdf`  
  - IBM Quantum Hub(Keio) 공식 배포자료 성격. 알고리즘/한계(노이즈, error mitigation) 서술 존재.
- (Tavily 내 링크) IBM Research blog/IBM Newsroom(2021): 공식 커뮤니케이션(다만 블로그/뉴스룸은 “supporting”으로 분류하는 것이 안전)

※ **주의:** 현재 아카이브에 위 웹문서/PDF가 “파일로 저장”되어 있지 않고 tavily jsonl에 URL/요약만 있습니다. 보고서 작성 시에는 원문 인용을 위해 추가 수집(다운로드/스크린 캡처/본문 저장)이 필요할 수 있습니다.

### 2.2 OLED 재료탐색 “방법론 비교” 보조(양자컴퓨팅 직접 아님)
- OpenAlex `W4410193211`(GNN generator): 고속 탐색 파이프라인 대비군으로 활용 가능(“QC가 당장 이기는 지점/지지점은 어디인가” 비교).

### 2.3 오프토픽 가능(우선순위 낮음)
- quantum materials(물질) 리뷰, 미래 전망 글, 간암/건축 리뷰 등: 현재 보고서 포커스(OLED 발광재료 설계에서 QC 활용)와 거리 큼.

---

## 3) 우선 읽기 리스트(최대 12개, rationale 포함)

1. `archive/tavily_search.jsonl`  
   - **OLED×양자컴퓨팅 직접 링크들이 여기에 집중**. 산업(OTI Lumionics) 및 IBM/Keio/Mitsubishi/JSR 트랙을 한 번에 스캔 가능.

2. `archive/20260110_qc-oled-index.md`  
   - 수집 범위/누락 파악(왜 OpenAlex가 OLED-QC 논문을 거의 못 잡았는지) + 전체 지도 역할.

3. `archive/openalex/works.jsonl`  
   - OpenAlex로 잡힌 학술 소스의 적합도 선별(오프토픽 제거 근거 확보).

4. `archive/openalex/text/W4417018335.txt`  
   - “quantum advantage 평가 프레임”이 쓸만하면, **‘근거 강도 표기 + 병목(스케일링/오차/비용)’** 정리에 활용. (단, 출처 신뢰도 낮으면 폐기)

5. `archive/openalex/text/W4410193211.txt`  
   - QC 대신 **클래식 ML 기반 분자 생성 워크플로**를 정확히 정리해 QC 워크플로와 비교/대조(데이터 파이프라인, 재현성, 스케일링).

6. `archive/openalex/text/W4406477905.txt`  
   - “quantum materials” 리뷰가 QC 알고리즘/워크플로를 다루는지 확인. 다루지 않으면 제외.

7. `archive/openalex/text/W4410446803.txt`  
   - “12~24개월 전망” 문장 근거가 빈약할 위험이 있어, **사용 여부를 빠르게 판정**하기 위한 스캔.

8. `archive/_log.txt`  
   - 검색/다운로드 과정에서의 에러/쿼리 편향 확인 → “공개정보 한계” 섹션에 메타 근거로 사용 가능.

9. `archive/_job.json`  
   - 동일 목적(수집 파라미터/언어/기간/결과 제한) 확인.

10. `archive/openalex/text/W4406330631.txt`  
   - OLED 발광(organoluminophores) 배경 정리에 일부 쓸 여지는 있으나 QC와 직접 연결이 약함. (시간 남을 때)

11. `archive/openalex/text/W4406707630.txt`  
12. `archive/openalex/text/W4406399672.txt`  
   - 현재 포커스와 불일치 가능성이 커서 **사실상 제외 후보**(필요 시 “잡음 소스”로만 처리).

---

## 4) 추천 읽기/확장 수집 플랜(간단)

- 1단계(필수): `tavily_search.jsonl`에서 **OLED×QC 직접 근거(IBM/Keio/npj 논문, Mitsubishi PDF, OTI Lumionics JCTC/ arXiv 언급)**를 추출해 “primary vs supporting”로 라벨링.
- 2단계(보강): OpenAlex 텍스트는 “양자우위/워크플로/평가틀”에 실제로 도움되는 것만 선별.
- 3단계(갭 메우기): **삼성디스플레이/LG디스플레이/UDC**는 현재 아카이브에 “공식 1차 문서”가 거의 없으므로, tavily 결과에서 해당 회사 직접 출처(공식 PR, IR, 특허, 학회 발표자료)가 있는지 추가로 찾아야 함(없다면 “공개 정보의 한계”로 명시).

원하시면, 다음 단계로 제가 `tavily_search.jsonl` 안에서 **산업(OTI Lumionics, 디스플레이 업체) vs 학계(알고리즘/워크플로)**로 항목을 재분류한 “근거 테이블(주장-근거-한계)” 초안을 먼저 뽑아드릴 수 있습니다.