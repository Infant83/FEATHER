업데이트된 Plan (완료표시 + 누락 단계 보완):

- [x] 범위·요구사항 확정 — “지난 12개월(2025-01~2026-01)” 기준, OLED 발광재료 관점 핵심 질문/산출물(주장→근거→한계→해석, 근거강도) 체크리스트로 고정  
- [x] 인덱스/메타 1차 점검 — `archive/20260110_qc-oled-index.md`, `archive/_job.json`, `archive/_log.txt`로 수집 커버리지·편향·누락(특히 12개월 내 공백) 근거화  
- [x] Tavily 결과에서 “OLED×양자컴퓨팅 직접 근거” 추출 — `archive/tavily_search.jsonl` 스캔 완료(12개월 내/외 구분 필요 후보: 2025-06-18 OTI/GlobeNewswire, 그 외 2021 IBM/npj/MCGC 등) + primary/supporting 라벨링 이슈(원문 부재/요약만 존재) 확인  
- [ ] OpenAlex 학술 소스 적합도 필터링 — `archive/openalex/works.jsonl` 및 관련 txt/PDF에서 OLED·excited-state·TADF/CP-OLED·전자전이 계산·QC 알고리즘 언급 여부로 온토픽/오프토픽 판정 및 채택 목록 확정  
- [ ] “주요 흐름(알고리즘·워크플로·데이터 파이프라인)” 근거 정리 — VQE/qEOM-VQE/VQD, error mitigation, (QC+클래식) 하이브리드 파이프라인을 소스별로 매핑하고 재현성/스케일링 제약을 함께 추출  
- [ ] OLED 발광재료 적용·성과 정리 — 형광/인광/TADF/CP-OLED별로 계산 타깃(여기상태, 전이, ΔEST 등), 성과지표, 비교기준(클래식 QC/DFT/ML)과 한계를 “근거 테이블(10~15항목)”로 작성  
- [ ] 산업 파트(삼성/LG/UDC) ‘있음/없음’ 판정 — 아카이브 내 **‘QC 적용’ 직접 근거** 유무를 우선 확정(현 상태: 삼성/LG/UDC는 대부분 OLED 일반/공급계약 등으로 QC 직접 근거 빈약)하고, 없을 경우 검색로그/인덱스 한계를 근거로 “공개정보 부재” 명시  
- [ ] 시나리오 2~3개 + 12~24개월 전망 구성 — 연구·산업 간 간극(수율/수명/공정호환/비용/신뢰성)과 병목을 축으로 시나리오 제시, 의사결정자용 후속 질문(검증 실험/데이터 요구/ROI 가정) 도출  
- [ ] MIT Tech Review 템플릿으로 최종 보고서 조립 — Executive Summary→What Changed→Why It Matters→Technical Context→Industry Implications→Risks & Gaps + 각 주장에 출처·근거강도·불확실성 태깅 및 교차검증  
- [ ] (누락 보완) 원문 직접 인용 불가 소스 처리 — Nature/npj 페이지, GlobeNewswire 등 **“tavily 요약만 존재(원문 추출 파일 부재)”**는 직접 인용에서 제외하고 supporting/메타로만 사용 규칙 추가  
- [ ] (누락 보완) 12개월 내 직접근거 공백 처리 — 2025-01~2026-01 내 ‘OLED×QC 직접 논문/공식문서’가 부족할 경우, **공백 자체**를 수집·접근제한(예: OpenAlex 403, 유료벽) 및 검색결과 부재로 메타근거화  
- [ ] (누락 보완) 링크드인/유료벽 자료 취급 규정 — LinkedIn, OLED-Info Pro 등은 근거강도 하향/참고로만 두고, 가능하면 1차 논문·공식문서로 대체 확인 단계 추가